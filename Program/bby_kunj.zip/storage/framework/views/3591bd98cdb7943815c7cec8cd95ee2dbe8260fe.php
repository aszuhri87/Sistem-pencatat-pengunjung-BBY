<!DOCTYPE html>
<html>
<head>
    <title>Halaman Pemohon</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="<?php echo e(url('/')); ?>/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/css/styles.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/font-awesome.min.css')); ?>">
    <script src="<?php echo e(asset('lte/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('lte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<link href="<?php echo e(captcha_layout_stylesheet_url()); ?>" type="text/css" rel="stylesheet">
</head>

<body>

    <div class="container">
        <div class="card mt-5">
            


            <div class="row" style="padding:2%">
                <div class="col-md-6 col-md-offset-3">

                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                    </div>
                  <?php endif; ?>



                    <form action="<?php echo e(url('permohonan')); ?>" method="post">

                        <?php echo e(csrf_field()); ?>


                        <label for="name">Nama Anda</label>
                        <input class="form-control" type="text" name="name" placeholder="Nama" />
                        <?php if($errors->has('name')): ?>
                        <span class="help-block">
                          <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                        <?php endif; ?>

                        <label for="email">Alamat Email</label>
                        <input class="form-control" type="email" name="email" placeholder="Email" />
                        <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>

                        <label for="message">Isi Pesan Permohonan</label>
                        <textarea class="form-control" name="message" id="" style="height:10%;" placeholder="Pesan permohonan" cols="10" rows="10"></textarea>

                        <?php if($errors->has('message')): ?>
                        <span class="help-block">
                          <strong><?php echo e($errors->first('message')); ?></strong>
                        </span>
                      <?php endif; ?>
                      <br>

                                <!-- show captcha image html -->
                                <label>Retype the characters from the picture</label>
                                <?php echo captcha_image_html('ContactCaptcha'); ?>

                                <input type="text" id="CaptchaCode" name="CaptchaCode">

                                <?php if($errors->has('CaptchaCode')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('CaptchaCode')); ?></strong>
                                </span>
                                <?php endif; ?>



                        <button class="btn btn-primary btn-block">Send</button>
                    <form>
                </div>
            </div>

        </div>


    </div>


</body>


<script>
 $(".btn-refresh").click(function(){

$.ajax({

   type:'GET',

   url:'/refreshCaptcha',

   success:function(data){

      $(".captcha span").html(data.captcha);

   }

});

});
    </script>

</html>
<?php /**PATH E:\xampp\htdocs\bby_kunj\resources\views/pengunjung/permohonan.blade.php ENDPATH**/ ?>