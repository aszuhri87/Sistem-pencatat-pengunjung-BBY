<?php $__env->startSection('content'); ?>
    <?php if(count($errors) > 0): ?>
   <div class="alert alert-danger errors-list">
      <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </div>
   <?php endif; ?>




<form method="post" action="<?php echo e(url('/')); ?>/pengunjung/store">
<div class="col-sm-6" style="padding:2%;">
    
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
         <label for="nama_pengunjung">Nama</label>
         <input type="text" class="form-control" value="<?php echo e(old('nama_pengunjung')); ?>" name="nama_pengunjung" id="nama_pengunjung" required>
      </div>
      <div class="form-group">
         <label for="no_hp">Nomor Telepon</label>
         <input type="text" name="no_hp" value="<?php echo e(old('no_hp')); ?>" class="form-control" id="no_hp" required>
      </div>

      <div class="form-group">
         <label for="keperluan">Keperluan</label>
         <input type="text" name="keperluan" value="<?php echo e(old('keperluan')); ?>" class="form-control" id="keperluan" required>
      </div>
      <label>Retype the characters from the picture</label>
      <?php echo captcha_image_html('ContactCaptcha'); ?>

      <input type="text" id="CaptchaCode" name="CaptchaCode">

      <?php if($errors->has('CaptchaCode')): ?>
      <span class="help-block">
          <strong><?php echo e($errors->first('CaptchaCode')); ?></strong>
      </span>
      <?php endif; ?>

    <br>

</div>
<div class="col-sm-6" style="padding:2%;">

      <div class="form-group">
         <label for="nama_tempat">Instansi</label>
         <input type="text" class="form-control" value="<?php echo e(old('nama_tempat')); ?>" name="nama_tempat" id="nama_tempat">
      </div>
      <div class="form-group">
         <label for="alamat">Alamat</label>
         <input type="text" class="form-control" value="<?php echo e(old('alamat')); ?>" name="alamat" id="alamat">
      </div>
      <div class="form-group">

        <label for="nama_pegawai">Bertemu dengan</label>
            <select name="pegawai_id" class="form-control">

                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pe->id); ?>"><?php echo e($pe->nama_pegawai); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
         
      </div>



    <button type="submit" name="btn_submit" value="Submit" class="btn bg-primary" >Submit</button>


</div>


<div style= "padding-left:2%;">

</div>
</form>
<br>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengunjung.tampilan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\bby_kunj\resources\views/pengunjung/tambah.blade.php ENDPATH**/ ?>