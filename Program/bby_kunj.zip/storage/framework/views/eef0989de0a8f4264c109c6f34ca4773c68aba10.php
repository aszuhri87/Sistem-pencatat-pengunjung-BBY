<?php echo e($slot); ?>

<?php /**PATH E:\xampp\htdocs\bby_kunj\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>