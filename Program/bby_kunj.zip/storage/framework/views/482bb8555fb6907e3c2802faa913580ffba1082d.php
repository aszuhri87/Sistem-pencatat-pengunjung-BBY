
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pengunjung</title>
    <link href="<?php echo e(url('/')); ?>/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/css/styles.css" rel="stylesheet">


  </head>


  <body>
    <div class="container">
        <div class="card mt-5">

            <div class="card-header bg-primary">

               <h2> Edit Data </h2>
            </div>


              <div class="col-lg-12"></div>
              <div class="col-lg-12">
              <?php if(Session::has('message')): ?>
              <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
              <?php endif; ?>
    <?php if(count($errors) > 0): ?>
   <div class="alert alert-danger errors-list">
      <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </div>
   <?php endif; ?>



<form method="post" action="<?php echo e(url('/')); ?>/pengunjung/<?php echo e($pengunjung->id); ?>">
<div class="col-md-6" style="padding:2%;">
    <?php echo e(method_field('PATCH')); ?>

      <?php echo e(csrf_field()); ?>



        <label for="nama_pegawai">Pegawai Yang diganti</label>
            <select name="pegawai_id" class="form-control">

                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pe->id); ?>" <?php echo e(in_array($pe->id, $pengunjung->pegawai->pluck('id')
                ->toArray()) ? 'selected':''); ?>><?php echo e($pe->nama_pegawai); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        <label for="status">Status</label>
            <select name="status" class="form-control">
                <option value="Tidak dilayani"><?php echo e('Tidak dilayani'); ?></option>
                <option value="Dilayani"><?php echo e('Dilayani'); ?></option>
            </select>
         
      </div>




</div>



<div style= "padding:2%;">
    <button type="submit" name="btn_submit" value="Submit" class="btn bg-primary" >Edit</button>
</div>
</form>




</div>

</div>

</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\bby_kunj\resources\views/pengunjung/edit.blade.php ENDPATH**/ ?>