<footer class="main-footer">
    <!-- To the right -->

    <!-- Default to the left -->
    <strong>Copyright &copy; 2020 <a href="https://balaibahasadiy.kemdikbud.go.id/">Balai Bahasa Yogyakarta</a>.</strong> All rights reserved.
  </footer>
</div>
