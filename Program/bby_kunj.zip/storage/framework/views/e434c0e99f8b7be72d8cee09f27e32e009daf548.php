<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>Dashboard</title>



  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('lte/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('lte/dist/css/adminlte.min.css')); ?>">

  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/icofont.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
  
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.js"></script>
 </head>


</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->

  <?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- /.navbar -->

  <!-- Main Sidebar Container -->

  <?php echo $__env->make('admin/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Data Kunjungan</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Data Kunjungan</li>
            </ol>

          </div><!-- /.col -->
        </div><!-- /.row -->

      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <?php if(Session::has('status')): ?>
    <div class="alert alert-default-info"><?php echo e(Session::get('status')); ?></div>
    <?php endif; ?>

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">

        <div class="card-body">
            <a href="/pengunjung/tambah" target="_blank" class="btn btn-primary">Tambah Pengunjung</a>
            <a href="/pengunjung/trash_all" class="btn btn-danger">Move to Bin</a>

            <form action="data_pengunjung" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="row mt-md-3">
                <label for="from" class="col-form-label">From</label>
                    <div class="col-md-2">
                    <input type="date" class="form-control input-sm" id="from" name="from">
                    </div>
                    <label for="from" class="col-form-label">To</label>
                    <div class="col-md-2">
                        <input type="date" class="form-control input-sm" id="to" name="to">
                    </div>

                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary btn-md" name="search" >Filter Tanggal</button>
                        <button type="submit" class="btn btn-success btn-md" name="exportExcel" >Export Excel</button>

                    </div>
                    <div class="col-sm-2">
                        <input type="text" class="form-control input-sm" id="nama" name="nama" placeholder="Cari nama">
                    </div>
                    <div class="col-md">
                        <button type="submit" class="btn btn-primary btn-md" name="cari" >Cari</div></button>
                    </div>
                </div>



            </form>


            <table class="table table-bordered table-hover table-striped table-responsive-sm " id="order_table">
                <thead>
                    <tr class="text-xs">
                        <th>No</th>
                        <th>Nama</th>
                        <th>Instansi  </th>
                        <th>Alamat  </th>
                        <th>Nomor Telepon</th>
                        <th>Tanggal</th>
                        <th>Keperluan</th>
                        <th>Bertemu dengan</th>
                        <th>Status</th>
                        <th>Aksi</th>

                    </tr>
                </thead>
                <tbody>

                    <?php

                    $i=1;

                    ?>
                    <?php $__currentLoopData = $pengunjung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-xs">
                    <td><?php echo e($i); ?></td>
                        <td><?php echo e($p->nama_pengunjung); ?></td>
                        <td><?php echo e($p->asal->nama_tempat); ?></td>
                        <td><?php echo e($p->asal->alamat); ?></td>
                        <td><?php echo e($p->no_hp); ?></td>
                        <td><?php echo e($p->created_at); ?></td>
                        <td><?php echo e($p->keperluan); ?></td>
                        <td><?php echo e($p->pegawai->nama_pegawai); ?></td>


                        <?php if($p->status=='Dilayani'): ?>
                           <td><span style="font-size: 8pt;" class="badge badge-success"><?php echo e($p->status); ?></span></td>
                        <?php else: ?>
                           <td><span style="font-size: 8pt;" class="badge badge-danger"><?php echo e($p->status); ?></span></td>
                        <?php endif; ?>


                        <td>
                            <a href="/pengunjung/<?php echo e($p->id); ?>/edit" class="fa fa-2x fa-edit text-warning" style="padding-right: 10%; padding-bottom: 10%;" ></a>


                        <a href="/pengunjung/hapus/<?php echo e($p->id); ?>" class=" fa fa-2x fa-trash-alt text-fuchsia"></a>




                        </td>
                    </tr>
                    <?php
                       $i++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <br>
                </tbody>
            </table>
            
        </div>



      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->

  <!-- /.content-wrapper -->


  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->


<!-- jQuery -->
<script src="<?php echo e(asset('lte/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('lte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('lte/dist/js/adminlte.min.js')); ?>"></script>

</body>
</html>
<?php /**PATH E:\xampp\htdocs\bby_kunj\resources\views/admin/admin.blade.php ENDPATH**/ ?>